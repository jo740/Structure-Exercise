import UIKit

struct enginetypesfornissan {
    var option1 : String
    var option2 : String
    var option3 : String
}
   
let enginetypes = enginetypesfornissan(option1: "VEngine", option2: "twincylinders", option3: "fourcylinders")

print(("Engine options are ") + (enginetypes.option1 ) ,  (enginetypes.option2  ) , (enginetypes.option3))
